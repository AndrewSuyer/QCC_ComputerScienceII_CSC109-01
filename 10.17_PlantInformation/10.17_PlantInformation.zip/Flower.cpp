/*
 * Copyright 2023
 * Created by Andrew Suyer
 * 10.17 Plant information
 */


#include "Flower.h"
#include <iostream>


void Flower::SetPlantType(bool userIsAnnual) {
    isAnnual = userIsAnnual;
}

bool Flower::GetPlantType() const {
    return isAnnual;
}

void Flower::SetColorOfFlowers(const std::string& userColorOfFlowers) {
    colorOfFlowers = userColorOfFlowers;
}

const std::string& Flower::GetColorOfFlowers() const {
    return colorOfFlowers;
}

void Flower::PrintInfo() const {
    std::cout << "   Plant name: " << plantName << std::endl;
    std::cout << "   Cost: " << plantCost << std::endl;
    std::cout << "   Annual: " << std::boolalpha << isAnnual << std::endl;
    std::cout << "   Color of flowers: " << colorOfFlowers << std::endl;
}
