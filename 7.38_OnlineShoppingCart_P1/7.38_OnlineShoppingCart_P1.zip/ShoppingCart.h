/*
 * Copyright 2023
 * Created by Andrew Suyer
 * 7.38 Online shopping cart
 */


#ifndef INC_7_38_ONLINESHOPPINGCART_P1_SHOPPINGCART_H
#define INC_7_38_ONLINESHOPPINGCART_P1_SHOPPINGCART_H

#include "ItemToPurchase.h"

#include <string>
#include <vector>

class ShoppingCart
{
public:

    ShoppingCart();

    ShoppingCart(const std::string& customerName, const std::string& currentDate);


    const std::string& GetCustomerName() const;

    const std::string& GetDate();


    void AddItem(const ItemToPurchase& itemToPurchase);

    void RemoveItem(const std::string& itemName);

    void ModifyItem(const ItemToPurchase& itemToPurchase);


    int GetNumItemsInCart() const;

    int GetCostOfCart() const;


    void PrintTotal() const;

    void PrintDescriptions() const;


private:

    std::string customerName;
    std::string currentDate;
    std::vector<ItemToPurchase> cartItems;

};


#endif // INC_7_38_ONLINESHOPPINGCART_P1_SHOPPINGCART_H
