/*
 * Copyright 2023
 * Created by Andrew Suyer
 * 7.38 Online shopping cart (part 1)
 */

#ifndef INC_7_38_ONLINESHOPPINGCART_P1_ITEMTOPURCHASE_H
#define INC_7_38_ONLINESHOPPINGCART_P1_ITEMTOPURCHASE_H

#include <string>

class ItemToPurchase
{
public:

    ItemToPurchase();

    ItemToPurchase(const std::string& name, const std::string& description, int price = 0, int quantity = 0);


    void SetName(const std::string& name);

    const std::string& GetName() const;


    void SetDescription(const std::string& descrition);

    const std::string& GetDescription() const;


    void SetPrice(int price);

    int GetPrice() const;


    void SetQuantity(int quantity);

    int GetQuantity() const;


    void PrintItemCost() const;

    void PrintItemDescription() const;

private:

    std::string itemName;
    std::string itemDescription;
    int itemPrice;
    int itemQuantity;

};


#endif // INC_7_38_ONLINESHOPPINGCART_P1_ITEMTOPURCHASE_H
